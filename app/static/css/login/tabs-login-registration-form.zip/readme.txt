
"Tabs Login & Registration Form" 

Release:  v1.0   
Date:     December/5/2016


Files Structure
------------------------------------------------- 

/bootstrap	- contains bootstrap css, js and fonts
/css		- contains main css


Features
-------------------------------------------------

    - Built on Bootstrap v3.3.7
    - Fully Responsive
    - Stylesh Background Linear Gradient Color
    - HTML5 & CSS3
    - Login/Signin Forms
    - One Page Tabs Click
    - HTML 5 Validation
    - Easy to use
    - Easy to customize
	

Credits
--------------------------------------------------
Jquery
Bootstrap
font-awesome


License
-------------------------------------------------

You Are Allowed To:

- You have the rights to use the this theme for personal and commercial project(s) purposes.
- Create website/application for clients.
- You can modify/customize the files to fit your needs.

You Are Not Allowed To:

- You are NOT allowed to use one purchase more than one projects, if you need to use more than one project, you have to purhcase more licence
- You are NOT allowed to claim credit or ownership for any of the files found on bootstraplayout.com
- You cannot resell, redistribute, license, or sub-license any of the files found on bootstraplayout.com without direct permission from bootstraplayout.com


Support
----------------------------------------------------
If you have some questions or help please email us at contact@bootstraplayouts.com  


